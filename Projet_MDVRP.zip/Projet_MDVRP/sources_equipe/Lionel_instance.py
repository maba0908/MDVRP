"""
Structure de données commune d'une instance MDVRP / MDVRPTW.

C'est le « contrat » partagé par toute l'équipe : le PLNE et la recherche tabou
lisent exactement le même objet (ou le même fichier JSON, voir to_json).

Numérotation des lieux (identique au solveur tabu_vrp du projet) :
    0                 = premier dépôt
    1 .. n            = clients (même numéro que dans les fichiers d'origine)
    n+1 .. n+m-1      = autres dépôts
On n'a jamais besoin de retenir cette règle : utiliser inst.depots (liste des
lieux-dépôts) et inst.customers (liste des clients).
"""
from dataclasses import dataclass, field
from functools import cached_property
import json
import math
import os

import numpy as np

INF = float("inf")


@dataclass
class MDVRPInstance:
    """Données d'une instance à m dépôts et n clients."""
    name: str
    coords: np.ndarray                 # (n + m, 2) coordonnées de tous les lieux
    demand: np.ndarray                 # (n + m,)   demande (0 pour un dépôt)
    capacity: float                    # Q, identique pour tous les camions
    m: int                             # nombre de dépôts
    trucks: list                       # nombre de camions de chaque dépôt (longueur m)
    max_duration: list | None = None   # durée maximale d'une tournée, par dépôt (None = aucune)
    service: np.ndarray | None = None  # durée de service de chaque lieu (None = 0)
    tw_early: np.ndarray | None = None  # fenêtres de temps (MDVRPTW) ; None = sans fenêtres
    tw_late: np.ndarray | None = None
    distance_rule: str = "euclid"      # "euclid" (exacte) ou "nint" (arrondie à l'entier)
    bks: float | None = None           # meilleure valeur connue (si disponible)
    meta: dict = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Accès pratiques
    # ------------------------------------------------------------------
    @property
    def n(self) -> int:
        """Nombre de clients."""
        return len(self.demand) - self.m

    @property
    def depots(self) -> list:
        """Lieux des dépôts (indices dans coords / dist)."""
        return [0] + list(range(self.n + 1, self.n + self.m))

    @property
    def customers(self) -> list:
        """Lieux des clients : 1 .. n."""
        return list(range(1, self.n + 1))

    @property
    def total_trucks(self) -> int:
        return int(sum(self.trucks))

    @property
    def min_trucks(self) -> int:
        """Borne inférieure triviale : ceil(somme des demandes / Q)."""
        return int(math.ceil(self.demand.sum() / self.capacity - 1e-9))

    @property
    def has_time_windows(self) -> bool:
        return self.tw_early is not None

    @property
    def has_duration_limit(self) -> bool:
        return self.max_duration is not None and any(d < INF for d in self.max_duration)

    def depot_index(self, location: int) -> int:
        """Numéro (0..m-1) du dépôt situé au lieu `location`."""
        return self.depots.index(location)

    # ------------------------------------------------------------------
    # Matrice des distances : calculée UNE SEULE FOIS par instance
    # ------------------------------------------------------------------
    @cached_property
    def dist(self) -> np.ndarray:
        """Matrice (n+m) x (n+m) des distances (= temps de trajet).

        Calculée au premier accès puis gardée en mémoire : les accès suivants
        sont gratuits. Conventions de la littérature, indispensables pour
        comparer nos coûts aux valeurs publiées :
          * Cordeau (p01..p23, pr01..pr20) : distance euclidienne exacte ;
          * Augerat (A, B, P) : distance euclidienne arrondie à l'entier le
            plus proche (convention TSPLIB « EUC_2D »)."""
        diff = self.coords[:, None, :] - self.coords[None, :, :]
        d = np.sqrt((diff ** 2).sum(axis=2))
        if self.distance_rule == "nint":
            d = np.floor(d + 0.5)          # nint de TSPLIB (pas d'arrondi « au pair »)
        elif self.distance_rule != "euclid":
            raise ValueError(self.distance_rule)
        d.setflags(write=False)            # protège la matrice partagée
        return d

    def nearest_depot(self) -> np.ndarray:
        """Pour chaque client 1..n, numéro (0..m-1) du dépôt le plus proche."""
        return np.argmin(self.dist[np.ix_(self.depots, self.customers)], axis=0)

    # ------------------------------------------------------------------
    # Affichage
    # ------------------------------------------------------------------
    def summary(self) -> dict:
        return {
            "nom": self.name, "clients": self.n, "dépôts": self.m,
            "capacité Q": self.capacity, "camions par dépôt": list(self.trucks),
            "camions minimum": self.min_trucks,
            "durée max": None if not self.has_duration_limit else list(self.max_duration),
            "fenêtres de temps": self.has_time_windows,
            "distances": self.distance_rule, "BKS": self.bks,
        }

    def __repr__(self):
        return (f"MDVRPInstance({self.name}: n={self.n}, m={self.m}, Q={self.capacity:g}, "
                f"camions={list(self.trucks)}, distances={self.distance_rule})")

    # ------------------------------------------------------------------
    # Échange de fichiers avec le reste de l'équipe
    # ------------------------------------------------------------------
    def to_dict(self, with_distances: bool = False) -> dict:
        def arr(a):
            return None if a is None else np.asarray(a).tolist()
        d = {
            "name": self.name, "m": self.m, "n": self.n,
            "depots": self.depots, "customers": self.customers,
            "coords": arr(self.coords), "demand": arr(self.demand),
            "capacity": self.capacity, "trucks": list(map(int, self.trucks)),
            "max_duration": None if self.max_duration is None
            else [None if x == INF else x for x in self.max_duration],
            "service": arr(self.service), "tw_early": arr(self.tw_early),
            "tw_late": arr(self.tw_late), "distance_rule": self.distance_rule,
            "bks": self.bks, "meta": self.meta,
        }
        if with_distances:
            d["dist"] = arr(self.dist)
        return d

    def to_json(self, path: str, with_distances: bool = False) -> None:
        """Écrit l'instance au format JSON partagé (voir README)."""
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(with_distances), f, ensure_ascii=False)

    @classmethod
    def from_dict(cls, d: dict) -> "MDVRPInstance":
        def arr(a):
            return None if a is None else np.asarray(a, dtype=float)
        md = d.get("max_duration")
        inst = cls(name=d["name"], coords=arr(d["coords"]), demand=arr(d["demand"]),
                   capacity=float(d["capacity"]), m=int(d["m"]), trucks=list(d["trucks"]),
                   max_duration=None if md is None else [INF if x is None else x for x in md],
                   service=arr(d.get("service")), tw_early=arr(d.get("tw_early")),
                   tw_late=arr(d.get("tw_late")), distance_rule=d.get("distance_rule", "euclid"),
                   bks=d.get("bks"), meta=d.get("meta", {}))
        return inst

    @classmethod
    def from_json(cls, path: str) -> "MDVRPInstance":
        with open(path) as f:
            return cls.from_dict(json.load(f))

    # ------------------------------------------------------------------
    # Passerelle vers le solveur tabou du projet (paquet tabu_vrp)
    # ------------------------------------------------------------------
    def to_tabu_vrp(self):
        """Convertit l'instance pour la recherche tabou (même numérotation)."""
        from tabu_vrp import Instance
        inst = Instance(name=self.name, coords=self.coords.copy(), demand=self.demand.copy(),
                        capacity=self.capacity, dist=np.array(self.dist), m=self.m,
                        n_vehicles=self.total_trucks if self.m == 1 else None,
                        fleet=list(self.trucks) if self.m > 1 else None, bks=self.bks,
                        meta=dict(self.meta))
        if self.service is not None:
            inst.service = self.service.copy()
        if self.has_time_windows:
            inst.tw_early, inst.tw_late = self.tw_early.copy(), self.tw_late.copy()
            if inst.service is None:
                inst.service = np.zeros(len(self.demand))
        if self.has_duration_limit:
            inst.dmax = np.array([1e9 if x == INF else x for x in self.max_duration])
            if inst.service is None:
                inst.service = np.zeros(len(self.demand))
        return inst
