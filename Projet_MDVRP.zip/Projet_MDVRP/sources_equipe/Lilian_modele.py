from __future__ import annotations
import math
import random
from dataclasses import dataclass, field

EPS = 1e-9


# ----------------------------------------------------------------------
# Données
# ----------------------------------------------------------------------
@dataclass
class Instance: ## Regroupe toutes les données du problème
    clients_xy: list          # [(x, y), ...]
    demande: list              # demande de chaque client
    depots_xy: list           # [(x, y), ...]  (2 dépôts ici, mais générique)
    vehicules_par_depot: list  # nb de camions par dépôt, ex. [3, 3]
    capacite: float           # capacité d'un camion
    d: list = field(init=False) ## Table des distances

    def __post_init__(self):
        pts = list(self.clients_xy) + list(self.depots_xy)
        self.d = [[math.dist(a, b) for b in pts] for a in pts] ## Calcule la distance entre chaque points et les ajoute à d

    @property
    def n(self):
        return len(self.clients_xy)

    def dep_node(self, k): ## Permet de trouver l'indice du dépôt k dans la table des distances d
        return self.n + k


@dataclass
class Camion: ## Représente une tournée de camion
    depot: int                       # indice du dépôt (0 ou 1)
    clients: list = field(default_factory=list)
    chargement: float = 0.0                


@dataclass
class Solution:
    routes: list                     # une route par camion (vides autorisées)

    def cost(self, inst): ## Distance totale parcourue par l'ensemble des camions
        return sum(route_cost(inst, r) for r in self.routes)

    def copy(self): ## Permet d'explorer de nouvelles solutions sans modifier l'initiale
        return Solution([Camion(r.depot, r.clients[:], r.chargement) for r in self.routes])


def route_cost(inst, r): ## Calcule la distance d'un camion
    if not r.clients:
        return 0.0
    dep = inst.dep_node(r.depot)
    d = inst.d
    c = r.clients
    total = d[dep][c[0]] + d[c[-1]][dep]
    for a, b in zip(c, c[1:]):
        total += d[a][b]
    return total


def _prev(inst, r, i):
    return r.clients[i - 1] if i > 0 else inst.dep_node(r.depot)


def _next(inst, r, i):
    return r.clients[i + 1] if i + 1 < len(r.clients) else inst.dep_node(r.depot)


# ----------------------------------------------------------------------
# 1) Solution initiale : insertion la moins chère sur TOUTES les tournées
#    (donc des deux dépôts). Respecte capacité et nombre de camions car
#    on ne dispose que de vehicules_par_depot[k] tournées par dépôt.
# ----------------------------------------------------------------------
def initial_solution(inst: Instance, order="demande") : ## Créé le nbr de camions vide déf dans instance
    routes = [Camion(k) for k, nb in enumerate(inst.vehicules_par_depot) for _ in range(nb)]
    sol = Solution(routes)
    d = inst.d

    clients = list(range(inst.n))
    if order == "demand":        
        clients.sort(key=lambda c: -inst.demande[c]) # tri décroissant (gros clients plus dur à placer)
    elif order == "random":
        random.shuffle(clients) # Mélange aléatoire des clients pour obtenir une solution initiale nouvelle

    for c in clients:
        best = None  # (delta, route, position)
        for r in routes:
            if r.chargement + inst.demande[c] > inst.capacite + EPS:
                continue
            dep = inst.dep_node(r.depot)
            for pos in range(len(r.clients) + 1):
                p = r.clients[pos - 1] if pos > 0 else dep # Point avant le client à insérer
                q = r.clients[pos] if pos < len(r.clients) else dep # Point après le client à insérer
                delta = d[p][c] + d[c][q] - d[p][q] # Distance supplémentaire dûe à l'insertion d'un client
                if best is None or delta < best[0]:
                    best = (delta, r, pos)
        if best is None:
            raise ValueError(
                f"Client {c} impossible à placer : pas assez de capacité/véhicules "
                f"(essayer order='random' ou augmenter la flotte)."
            )
        _, r, pos = best
        r.clients.insert(pos, c)
        r.chargement += inst.demande[c]
    return sol


# ----------------------------------------------------------------------
# 2) Mouvements. Chaque générateur renvoie des tuples (delta, type, params).
#    delta < 0  <=>  amélioration. Les routes sont désignées par leur indice
#    dans sol.routes ; l'inter-dépôt est automatique (route.depot diffère).
# ----------------------------------------------------------------------
def relocate_moves(inst, sol):
    """Déplace un client vers une autre position (autre tournée ou même tournée)."""
    d = inst.d
    R = sol.routes
    for a, r1 in enumerate(R):
        for i, c in enumerate(r1.clients):
            p, q = _prev(inst, r1, i), _next(inst, r1, i)
            gain = d[p][c] + d[c][q] - d[p][q]
            for b, r2 in enumerate(R):
                if a == b:
                    # intra-tournée : on recalcule sur la liste modifiée
                    base = route_cost(inst, r1)
                    rest = r1.clients[:i] + r1.clients[i + 1:]
                    for j in range(len(rest) + 1):
                        if j == i:
                            continue
                        new = Camion(r1.depot, rest[:j] + [c] + rest[j:])
                        yield (route_cost(inst, new) - base, "relocate", (a, i, b, j))
                    continue
                if r2.chargement + inst.demande[c] > inst.capacite + EPS:
                    continue
                dep2 = inst.dep_node(r2.depot)
                for j in range(len(r2.clients) + 1):
                    p2 = r2.clients[j - 1] if j > 0 else dep2
                    q2 = r2.clients[j] if j < len(r2.clients) else dep2
                    add = d[p2][c] + d[c][q2] - d[p2][q2]
                    yield (add - gain, "relocate", (a, i, b, j))


def swap_moves(inst, sol):
    """Échange deux clients de deux tournées différentes (dépôts identiques ou non)."""
    d = inst.d
    R = sol.routes
    for a in range(len(R)):
        for b in range(a + 1, len(R)):
            r1, r2 = R[a], R[b]
            for i, c1 in enumerate(r1.clients):
                for j, c2 in enumerate(r2.clients):
                    if r1.chargement - inst.demande[c1] + inst.demande[c2] > inst.capacite + EPS:
                        continue
                    if r2.chargement - inst.demande[c2] + inst.demande[c1] > inst.capacite + EPS:
                        continue
                    p1, q1 = _prev(inst, r1, i), _next(inst, r1, i)
                    p2, q2 = _prev(inst, r2, j), _next(inst, r2, j)
                    delta = (d[p1][c2] + d[c2][q1] - d[p1][c1] - d[c1][q1]
                             + d[p2][c1] + d[c1][q2] - d[p2][c2] - d[c2][q2])
                    yield (delta, "swap", (a, i, b, j))


def two_opt_moves(inst, sol):
    """Inverse un segment de visites à l'intérieur d'une tournée (2-opt)."""
    d = inst.d
    for a, r in enumerate(sol.routes):
        m = len(r.clients)
        for i in range(m - 1):
            for j in range(i + 1, m):
                p, q = _prev(inst, r, i), _next(inst, r, j)
                ci, cj = r.clients[i], r.clients[j]
                delta = d[p][cj] + d[ci][q] - d[p][ci] - d[cj][q]
                yield (delta, "two_opt", (a, i, j))


def all_moves(inst, sol):
    yield from relocate_moves(inst, sol)
    yield from swap_moves(inst, sol)
    yield from two_opt_moves(inst, sol)


# ----------------------------------------------------------------------
# 3) Application d'un mouvement (modifie la solution en place)
# ----------------------------------------------------------------------
def apply_move(inst, sol, move):
    _, kind, prm = move # Distribue les éléments (delta, type_de_mouvement, paramètres) du mouvement à _, kind et prm
    R = sol.routes
    if kind == "relocate":
        tournee1, i, tournee2, j = prm # Distribue les paramètres du mouvement (numéro_tournée_a, position_du_client_dans_la_tournée_a, numéro_tournée_b, position_dans_la_tournée_b)
        c = R[tournee1].clients.pop(i)
        R[tournee2].clients.insert(j, c)
        if tournee1 != tournee2:
            R[tournee1].chargement -= inst.demande[c]
            R[tournee2].chargement += inst.demande[c]
    elif kind == "swap":
        tournee1, i, tournee2, j = prm
        c1, c2 = R[tournee1].clients[i], R[tournee2].clients[j]
        R[tournee1].clients[i], R[tournee2].clients[j] = c2, c1
        R[tournee1].chargement += inst.demande[c2] - inst.demande[c1]
        R[tournee2].chargement += inst.demande[c1] - inst.demande[c2]
    elif kind == "two_opt":
        tournee, i, j = prm
        R[tournee].clients[i:j + 1] = reversed(R[tournee].clients[i:j + 1])
    else:
        raise ValueError(kind)


# ----------------------------------------------------------------------
# 4) Descente locale (test des mouvements avant tabou (Mohammed))
# ----------------------------------------------------------------------
def recherche_locale(inst, sol, best_improvement=True):
    sol = sol.copy()
    while True:
        best = None
        for mv in all_moves(inst, sol):
            if mv[0] < -EPS and (best is None or mv[0] < best[0]): # Recherche du meilleur mouvement à faire
                best = mv
                if not best_improvement:
                    break
        if best is None:
            return sol
        apply_move(inst, sol, best)


# ----------------------------------------------------------------------
# Check rapide (à améliorer par Lionel)
# ----------------------------------------------------------------------
def check(inst, sol):
    seen = []
    for r in sol.routes:
        assert abs(sum(inst.demande[c] for c in r.clients) - r.chargement) < 1e-6, "vérifie si la charge enregistrée est juste"
        assert r.chargement <= inst.capacite + 1e-6, "vérifie si pas de surcharge"
        seen += r.clients # rassemble tous les clients visités pour vérifier si pas de double ou d'oubli
    assert sorted(seen) == list(range(inst.n)), "client oublié ou en double"
    for k, nb in enumerate(inst.vehicules_par_depot):
        assert sum(1 for r in sol.routes if r.depot == k) == nb, "nb de véhicules modifié"
    return True


if __name__ == "__main__":
    random.seed(1) # Pour que les résultates soient reproductibles
    n = 40
    inst = Instance(
        clients_xy=[(random.uniform(0, 100), random.uniform(0, 100)) for _ in range(n)],
        demande=[random.randint(1, 10) for _ in range(n)],
        depots_xy=[(20, 20), (80, 80)],
        vehicules_par_depot=[4, 4],
        capacite=60,
    )
    s0 = initial_solution(inst) # demande ou random
    check(inst, s0)
    s1 = recherche_locale(inst, s0)
    check(inst, s1)
    print(f"Cout initial : {s0.cost(inst):.2f}")
    print(f"Apres recherche locale : {s1.cost(inst):.2f}")
    for r in s1.routes:
        print(f"Depot {r.depot + 1} | charge {r.chargement:>3} | {r.clients}")