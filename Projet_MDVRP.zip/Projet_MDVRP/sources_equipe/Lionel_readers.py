"""
Lecture des instances de référence.

* read_cordeau : format de Cordeau (MDVRP type 2, MDVRPTW type 6), utilisé par
  les instances p01..p23 et pr01..pr20 ;
* read_cvrplib : format CVRPLIB / TSPLIB à un dépôt (jeux A, B, P d'Augerat),
  avec son fichier de solution optimale (.opt / .sol) ;
* read_solution_file : routes d'un fichier .opt / .sol de CVRPLIB.

Aucune bibliothèque externe n'est nécessaire (le format est lu à la main), ce
qui évite toute différence de convention entre les membres de l'équipe.
"""
import os
import re

import numpy as np

from .instance import INF, MDVRPInstance

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(HERE, "data")


def _rel(path: str) -> str:
    """Chemin relatif à la racine du dépôt quand c'est possible (pas de chemin propre à une machine)."""
    p = os.path.abspath(path)
    try:
        r = os.path.relpath(p, HERE)
    except ValueError:
        return p
    return p if r.startswith("..") else r.replace(os.sep, "/")

# Meilleures valeurs connues des trois instances de départ (voir README) :
#   p04 : la table compilée (Dzalbs & Kalganova, 2020) indique 1001,59 ; la recherche
#         tabou du projet a trouvé 1001,04 (solution fournie dans solutions/p04.json).
#   p05, p12 : 750,03 et 1318,95.
CORDEAU_BKS = {
    "p01": 576.87, "p02": 473.53, "p03": 641.19, "p04": 1001.04, "p05": 750.03,
    "p06": 876.50, "p07": 885.80, "p08": 4420.94, "p09": 3900.22, "p10": 3663.02,
    "p11": 3554.18, "p12": 1318.95, "p13": 1318.95, "p14": 1360.12, "p15": 2505.42,
    "p16": 2572.23, "p17": 2709.09, "p18": 3702.85, "p19": 3827.06, "p20": 4058.07,
    "p21": 5474.84, "p22": 5702.16, "p23": 6095.46,
}


# ---------------------------------------------------------------------------
# Format de Cordeau
# ---------------------------------------------------------------------------
def read_cordeau(path: str, name: str | None = None, bks: float | None = None) -> MDVRPInstance:
    """Lit une instance au format de Cordeau.

    Structure du fichier :
      ligne 1          : type  m  n  t   (type 2 = MDVRP, 6 = MDVRPTW ;
                         m = camions PAR dépôt, n = clients, t = dépôts)
      t lignes         : D  Q            (durée max d'une tournée, 0 = aucune ;
                         capacité des camions) pour chaque dépôt
      n lignes clients : i x y d q f a liste [e l]
                         (d = durée de service, q = demande, e l = fenêtre)
      t lignes dépôts  : i x y d q f a [e l]
    Distances : euclidiennes exactes (convention des articles de Cordeau).
    """
    with open(path) as f:
        rows = [line.split() for line in f if line.strip()]
    typ, mveh, n, t = (int(v) for v in rows[0][:4])
    if typ not in (2, 6):
        raise ValueError(f"{path} : type {typ} non géré (2 = MDVRP, 6 = MDVRPTW)")
    tw = typ == 6
    dq = [(float(r[0]), float(r[1])) for r in rows[1:1 + t]]

    def parse(r):
        x, y, d, q = (float(v) for v in r[1:5])
        if tw:                      # la fenêtre est toujours en fin de ligne
            e, lt = float(r[-2]), float(r[-1])
        else:
            e, lt = 0.0, INF
        return x, y, d, q, e, lt

    cust = [parse(r) for r in rows[1 + t:1 + t + n]]
    deps = [parse(r) for r in rows[1 + t + n:1 + t + n + t]]
    if len(cust) != n or len(deps) != t:
        raise ValueError(f"{path} : fichier incomplet")
    # numérotation commune : dépôt 1, clients 1..n, autres dépôts
    ordered = [deps[0]] + cust + deps[1:]
    coords = np.array([[r[0], r[1]] for r in ordered])
    demand = np.array([r[3] for r in ordered])
    demand[[0] + list(range(n + 1, n + t))] = 0.0
    service = np.array([r[2] for r in ordered])
    caps = {q for _, q in dq}
    if len(caps) != 1:
        raise ValueError("capacités différentes selon les dépôts : non géré")
    max_dur = [D if D > 0 else INF for D, _ in dq]
    nm = name or os.path.basename(path)
    inst = MDVRPInstance(
        name=nm, coords=coords, demand=demand, capacity=caps.pop(), m=t,
        trucks=[mveh] * t,
        max_duration=max_dur if any(x < INF for x in max_dur) else None,
        service=service if (np.any(service > 0) or tw) else None,
        distance_rule="euclid", bks=bks if bks is not None else CORDEAU_BKS.get(nm),
        meta={"source": "Cordeau", "path": _rel(path), "type": typ})
    if tw:
        inst.tw_early = np.array([r[4] for r in ordered])
        inst.tw_late = np.array([r[5] for r in ordered])
    return inst


def cordeau(name: str) -> MDVRPInstance:
    """Raccourci : cordeau("p04") lit data/cordeau/p04."""
    return read_cordeau(os.path.join(DATA, "cordeau", name), name=name)


# ---------------------------------------------------------------------------
# Format CVRPLIB (Augerat A, B, P)
# ---------------------------------------------------------------------------
def read_cvrplib(path: str, sol_path: str | None = None) -> MDVRPInstance:
    """Lit une instance CVRPLIB à un dépôt (format TSPLIB, EUC_2D).

    Le nombre de camions est le k du nom (A-n32-k5 -> 5 camions), comme dans
    les optimums publiés. Les clients gardent le numéro des solutions
    publiées : le nœud k+1 du fichier devient le client k ; le dépôt (nœud 1
    du fichier) devient le lieu 0. Distances arrondies à l'entier (nint)."""
    with open(path) as f:
        lines = [line.strip() for line in f]
    head, coords, demand, depot = {}, {}, {}, []
    section = None
    for line in lines:
        if not line or line.startswith("EOF"):
            continue
        if line.endswith("SECTION"):
            section = line
            continue
        if section is None and ":" in line:
            key, val = line.split(":", 1)
            head[key.strip().upper()] = val.strip()
            continue
        parts = line.split()
        if section == "NODE_COORD_SECTION":
            coords[int(parts[0])] = (float(parts[1]), float(parts[2]))
        elif section == "DEMAND_SECTION":
            demand[int(parts[0])] = float(parts[1])
        elif section == "DEPOT_SECTION":
            v = int(parts[0])
            if v > 0:
                depot.append(v)
    if head.get("EDGE_WEIGHT_TYPE", "EUC_2D").upper() != "EUC_2D":
        raise ValueError("seules les distances EUC_2D sont gérées")
    if depot != [1]:
        raise ValueError(f"dépôt attendu au nœud 1, trouvé {depot}")
    ids = sorted(coords)
    name = head.get("NAME", os.path.basename(path).rsplit(".", 1)[0])
    match = re.search(r"-k(\d+)", name)
    k = int(match.group(1)) if match else None
    inst = MDVRPInstance(
        name=name, coords=np.array([coords[i] for i in ids]),
        demand=np.array([demand[i] for i in ids]), capacity=float(head["CAPACITY"]),
        m=1, trucks=[k], distance_rule="nint",
        meta={"source": "CVRPLIB (Augerat et al., 1995)", "path": _rel(path)})
    if inst.trucks[0] is None:
        inst.trucks = [inst.min_trucks]
    if sol_path and os.path.exists(sol_path):
        sol = read_solution_file(sol_path)
        inst.bks = sol["cost"]
        inst.meta["published_routes"] = sol["routes"]
    return inst


def augerat(name: str) -> MDVRPInstance:
    """Raccourci : augerat("A-n32-k5") lit data/augerat/A/A-n32-k5.vrp et son optimum."""
    base = os.path.join(DATA, "augerat", name[0], name)
    return read_cvrplib(base + ".vrp", base + ".opt")


def augerat_names(sets=("A", "B", "P")) -> list:
    """Noms des instances d'Augerat disponibles, par jeu puis par taille."""
    out = []
    for s in sets:
        folder = os.path.join(DATA, "augerat", s)
        names = [f[:-4] for f in os.listdir(folder) if f.endswith(".vrp")]
        out += sorted(names, key=lambda x: int(re.search(r"-n(\d+)", x).group(1)))
    return out


def read_solution_file(path: str) -> dict:
    """Lit un fichier de solution CVRPLIB : lignes « Route #k: 3 7 12 », puis « Cost 784 »."""
    routes, cost = [], None
    with open(path) as f:
        for line in f:
            low = line.strip().lower()
            if low.startswith("route"):
                routes.append([int(v) for v in line.split(":", 1)[1].split()])
            elif low.startswith("cost"):
                cost = float(line.split()[1])
    return {"routes": routes, "cost": cost}
