# Bilan des premiers essais

- 34 fichiers sources lus et conservés.
- 3 benchmarks directement compatibles : p04, p05, p12.
- 17 sous-instances préparées : total 20 problèmes distincts.
- 3 répétitions par instance : 60 lancements.
- 60 solutions faisables selon le vérificateur indépendant de Lionel.
- Convention des distances conservée lors de la conversion.

## Qualité sur les références du guide

| Instance | Meilleur coût | Meilleur gap | Gap moyen |
|---|---:|---:|---:|
| p05 | 810.11 | 8.01 % | 13.26 % |
| p12 | 1465.22 | 11.09 % | 12.95 % |

Ces essais confirment le fonctionnement de la chaîne de calcul. Les gaps restent
à améliorer et les paramètres ne sont pas calibrés. Il faut encore la comparaison
au PLNE et aux bornes, davantage de répétitions, une étude de paramètres et une
interprétation complète pour le rendu final. Les 17 sous-instances partagent
les coordonnées de trois sources : cela limite la diversité géographique.

Aucun résultat optimal ou borne du PLNE n'a été inventé.

## Vérifications réalisées

Numérotation des lieux, conservation de l'arrondi CVRPLIB, cohérence des coûts,
conversion des tournées, refus des contraintes horaires non traitées et détection
d'un mauvais dépôt de retour. Pour relancer ces vérifications :

```bash
python tests/verifier_integration.py
```
