"""Passerelle entre les données de Lionel et le solveur Lilian/Mohamed."""
from collections import Counter
import math
import numpy as np
from donnees_mdvrp import MDVRPInstance, check_solution
from solveur_mdvrp import Instance, check


def convertir_instance(source):
    if source.has_time_windows or source.has_duration_limit:
        raise ValueError("Cette instance ajoute des contraintes horaires non traitées par le solveur.")
    clients = source.customers
    depots = source.depots
    cible = Instance(clients_xy=source.coords[clients].tolist(),
                     demande=source.demand[clients].tolist(),
                     depots_xy=source.coords[depots].tolist(),
                     vehicules_par_depot=[int(m) for m in source.trucks],
                     capacite=float(source.capacity))
    # Le solveur numérote d'abord les clients, puis tous les dépôts.
    # Lionel numérote le premier dépôt, puis les clients et les autres dépôts.
    ordre = clients + depots
    cible.d = np.asarray(source.dist)[np.ix_(ordre, ordre)].tolist()
    # Conserver la règle de distance est indispensable, notamment l'arrondi CVRPLIB.
    return cible


def exporter_routes(source, solution):
    """Chemins complets dans la numérotation de Lionel, tournées vides exclues."""
    return [[source.depots[r.depot]] + [source.customers[c] for c in r.clients]
            + [source.depots[r.depot]] for r in solution.routes if r.clients]


def verifier_commun(source, cible, solution):
    check(cible, solution)
    rep = check_solution(source, exporter_routes(source, solution),
                         declared_cost=solution.cost(cible))
    if not rep.feasible:
        raise ValueError(str(rep))
    return rep


def sous_instance(source, nombre):
    """Garder les premiers clients du fichier et les deux dépôts d'origine.

    Capacité, flotte, coordonnées et convention de distance sont conservées.
    C'est un NOUVEAU problème ; aucune BKS de l'instance mère n'est reprise.
    """
    if source.m != 2 or not 1 <= nombre < source.n:
        raise ValueError("Sous-instance attendue à deux dépôts avec moins de clients.")
    selection = source.customers[:nombre]
    ordre = [source.depots[0]] + selection + [source.depots[1]]
    return MDVRPInstance(name=f"{source.name}_sous_{nombre}",
        coords=source.coords[ordre].copy(), demand=source.demand[ordre].copy(),
        capacity=source.capacity,m=2,trucks=list(source.trucks),
        distance_rule=source.distance_rule,bks=None,
        meta={"parent":source.name,"regle":"premiers clients dans l'ordre du fichier",
              "clients_parent":selection,"flotte":"inchangée","reference":None})
