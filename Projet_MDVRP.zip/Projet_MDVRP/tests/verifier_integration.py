import sys,math,json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from donnees_mdvrp import MDVRPInstance,read_cordeau,check_solution
from integration import convertir_instance,exporter_routes,verifier_commun,sous_instance
from solveur_mdvrp import construire_initiale,recherche_tabou
from preparer_donnees import ROOT
count=0
for name in ['p04','p05','p12']:
 source=read_cordeau(str(ROOT/'data'/'cordeau'/name),name=name)
 sub=sous_instance(source,10);inst=convertir_instance(sub)
 sol=construire_initiale(inst)
 rep=verifier_commun(sub,inst,sol)
 assert abs(rep.cost-sol.cost(inst))<1e-7
 for a in range(inst.n):
  for b in range(inst.n):assert inst.d[a][b]==sub.dist[a+1,b+1]
 count+=1
# Vérifier le maintien de l'arrondi (une erreur à cet endroit fausserait les gaps).
s=MDVRPInstance('arrondi',np.array([[0,0],[1,1],[8,8]],float),
 np.array([0,1,0],float),2,2,[1,1],distance_rule='nint')
i=convertir_instance(s);assert i.d[0][1]==1 and math.dist((0,0),(1,1))!=i.d[0][1]
# Refuser les contraintes que le tabou actuel ne traite pas.
for name in ['p08','p13','pr01']:
 s=read_cordeau(str(ROOT/'data'/'cordeau'/name),name=name)
 try:convertir_instance(s)
 except ValueError:pass
 else:raise AssertionError(name)
# JSON aller-retour et cohérence d'une solution tabou.
s=MDVRPInstance.from_json(str(ROOT/'data'/'preparees'/'p12_sous_10.json'))
i=convertir_instance(s);sol=construire_initiale(i)
r=recherche_tabou(i,sol,iterations_max=50,temps_max=1)
assert verifier_commun(s,i,r['solution']).feasible
p=exporter_routes(s,r['solution']);p[0][-1]=s.depots[1] if p[0][0]==s.depots[0] else s.depots[0]
assert not check_solution(s,p).feasible
print('Tests passerelle OK : trois sources, numérotation, arrondi, contraintes horaires, JSON et retour dépôt.')
