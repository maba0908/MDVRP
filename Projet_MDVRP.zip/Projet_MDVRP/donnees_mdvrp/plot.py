"""Graphiques : instance et tournées, avec les dépôts bien visibles."""
import matplotlib.pyplot as plt
import numpy as np

from .checker import check_solution, normalize_solution
from .instance import MDVRPInstance

# une famille de couleurs par dépôt (les tournées d'un dépôt en déclinent les nuances)
DEPOT_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#6250d6", "#e87ba4", "#eda100"]
DEPOT_MARKERS = ["s", "D", "^", "v", "p", "h"]
INK, MUTED = "#0b0b0b", "#52514e"


def _style(ax, title):
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.set_aspect("equal")
    if title:
        ax.set_title(title, loc="left", fontsize=11, color=INK)


def _shade(hex_color, k, n):
    """Nuance k (sur n) d'une couleur : plus claire ou plus foncée."""
    rgb = np.array([int(hex_color[i:i + 2], 16) for i in (1, 3, 5)]) / 255
    f = 0.55 + 0.9 * (k / max(n - 1, 1)) if n > 1 else 1.0
    out = rgb * f if f <= 1 else rgb + (1 - rgb) * (f - 1) * 0.8
    return np.clip(out, 0, 1)


def draw_depots(inst: MDVRPInstance, ax):
    for d, loc in enumerate(inst.depots):
        x, y = inst.coords[loc]
        ax.scatter(x, y, marker=DEPOT_MARKERS[d % 6], s=220, color=DEPOT_COLORS[d % 6],
                   edgecolor=INK, linewidth=1.5, zorder=10)
        ax.annotate(f"Dépôt {d + 1}", (x, y), xytext=(8, 8), textcoords="offset points",
                    fontsize=9, weight="bold", color=INK, zorder=11,
                    bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.8))


def plot_instance(inst: MDVRPInstance, ax=None, annotate=False, title=None):
    """Clients colorés selon le dépôt le plus proche ; dépôts mis en évidence."""
    ax = ax or plt.subplots(figsize=(6, 6))[1]
    near = inst.nearest_depot()
    xy = inst.coords[1:inst.n + 1]
    size = 12 + 50 * inst.demand[1:inst.n + 1] / max(inst.demand.max(), 1)
    for d in range(inst.m):
        sel = near == d
        ax.scatter(xy[sel, 0], xy[sel, 1], s=size[sel], color=DEPOT_COLORS[d % 6], alpha=0.75,
                   lw=0, label=f"plus proches du dépôt {d + 1} ({sel.sum()})")
    if annotate:
        for i in inst.customers:
            ax.annotate(str(i), inst.coords[i], fontsize=6, color=MUTED, xytext=(2, 2),
                        textcoords="offset points")
    draw_depots(inst, ax)
    ax.legend(frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.07),
              ncol=min(inst.m, 3))
    _style(ax, title or f"{inst.name} — {inst.n} clients, {inst.m} dépôts, camions {inst.trucks}")
    return ax


def plot_solution(inst: MDVRPInstance, solution, ax=None, annotate=False, title=None, lw=1.3):
    """Tournées d'une solution : couleur = dépôt de départ (une nuance par
    tournée), flèche de sortie du dépôt, dépôts mis en évidence. Le titre
    rappelle le coût et le verdict du vérificateur."""
    ax = ax or plt.subplots(figsize=(7, 7))[1]
    paths = normalize_solution(inst, solution)
    rep = check_solution(inst, paths)
    by_depot = {}
    for p in paths:
        if p and p[0] in inst.depots:
            by_depot.setdefault(inst.depot_index(p[0]), []).append(p)
    for d, plist in by_depot.items():
        for k, p in enumerate(plist):
            c = _shade(DEPOT_COLORS[d % 6], k, len(plist))
            xy = inst.coords[p]
            ax.plot(xy[:, 0], xy[:, 1], "-", color=c, lw=lw, alpha=0.95)
            ax.scatter(xy[1:-1, 0], xy[1:-1, 1], s=16, color=c, zorder=3)
            if len(p) > 2:                                   # sens de parcours
                ax.annotate("", xy=xy[1], xytext=xy[0],
                            arrowprops=dict(arrowstyle="-|>", color=c, lw=lw))
    if annotate:
        for i in inst.customers:
            ax.annotate(str(i), inst.coords[i], fontsize=6, color=MUTED, xytext=(2, 2),
                        textcoords="offset points")
    draw_depots(inst, ax)
    handles = [plt.Line2D([], [], color=DEPOT_COLORS[d % 6], lw=2,
                          label=f"dépôt {d + 1} : {rep.routes_per_depot[d]} tournées "
                                f"/ {inst.trucks[d]} camions") for d in range(inst.m)]
    ax.legend(handles=handles, frameon=False, fontsize=8, loc="upper center",
              bbox_to_anchor=(0.5, -0.07), ncol=min(inst.m, 3))
    verdict = "réalisable" if rep.feasible else f"NON réalisable ({len(rep.errors)} erreurs)"
    _style(ax, title or f"{inst.name} — coût {rep.cost:.2f}, {verdict}")
    return ax
