"""
Ajout d'un second dépôt à une instance à un dépôt (jeux A, B, P d'Augerat).

Deux décisions doivent être explicites et reproductibles :

1. **La position du nouveau dépôt** (paramètre `position`) :
   * "kmeans" (par défaut) : les clients sont partagés en deux groupes par
     k-moyennes (graine fixe) ; le dépôt d'origine est rattaché au groupe dont
     le centre est le plus proche, et le nouveau dépôt est placé au centre de
     l'autre groupe (coordonnées arrondies à l'entier). C'est la règle utilisée
     dans les campagnes du projet ;
   * un couple (x, y) : position imposée à la main.
2. **La répartition des camions** (paramètre `trucks`) :
   * "copy" (par défaut) : chaque dépôt reçoit les k camions de l'instance
     d'origine (règle des campagnes du projet) ;
   * "split" : les k camions sont partagés entre les deux dépôts au prorata de
     la demande des clients dont ils sont le dépôt le plus proche (chaque dépôt
     en garde au moins assez pour ces clients si c'est possible) : même flotte
     totale qu'avec un dépôt ;
   * une liste [k1, k2] imposée à la main.
"""
import math

import numpy as np

from .instance import MDVRPInstance


def kmeans_position(inst: MDVRPInstance, seed: int = 0, iters: int = 100) -> np.ndarray:
    """Position du second dépôt selon la règle « kmeans » (voir en-tête)."""
    pts = inst.coords[1:inst.n + 1]
    rng = np.random.default_rng(seed)
    cent = pts[rng.choice(len(pts), 2, replace=False)].astype(float)
    for _ in range(iters):                                # algorithme de Lloyd
        lab = np.argmin(((pts[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2), axis=1)
        new = np.array([pts[lab == c].mean(axis=0) if np.any(lab == c) else cent[c]
                        for c in range(2)])
        if np.allclose(new, cent):
            break
        cent = new
    own = int(np.argmin(np.linalg.norm(cent - inst.coords[0], axis=1)))
    return np.round(cent[1 - own])


def split_trucks(inst2: MDVRPInstance, k: int) -> list:
    """Partage k camions entre les dépôts au prorata de la demande des clients
    les plus proches de chacun (méthode des plus forts restes)."""
    near = inst2.nearest_depot()
    q = inst2.demand[1:inst2.n + 1]
    load = np.array([q[near == d].sum() for d in range(inst2.m)])
    need = np.ceil(load / inst2.capacity - 1e-9).astype(int)
    share = k * load / load.sum()
    base = np.floor(share).astype(int)
    for d in np.argsort(-(share - base))[:k - base.sum()]:
        base[d] += 1
    if need.sum() <= k:                     # garantir le minimum de chaque dépôt
        while np.any(base < need):
            short = int(np.argmax(need - base))
            donor = int(np.argmax(base - need))
            base[short] += 1
            base[donor] -= 1
    return base.tolist()


def add_second_depot(inst: MDVRPInstance, position="kmeans", trucks="copy",
                     name: str | None = None) -> MDVRPInstance:
    """Renvoie une NOUVELLE instance à deux dépôts (l'instance d'origine n'est
    pas modifiée). Le nouveau dépôt est le lieu n+1 ; les distances suivent la
    même convention que l'instance d'origine (arrondi à l'entier pour Augerat).
    La position et la répartition des camions sont notées dans meta."""
    if inst.m != 1:
        raise ValueError("l'instance a déjà plusieurs dépôts")
    if isinstance(position, str):
        if position != "kmeans":
            raise ValueError(position)
        pos = kmeans_position(inst)
        rule = "kmeans (centre du groupe de clients non rattaché au dépôt d'origine)"
    else:
        pos = np.asarray(position, dtype=float)
        rule = "position imposée"
    k = int(inst.trucks[0])
    out = MDVRPInstance(
        name=name or f"{inst.name}-2dep",
        coords=np.vstack([inst.coords, pos[None, :]]),
        demand=np.concatenate([inst.demand, [0.0]]), capacity=inst.capacity, m=2,
        trucks=[k, k], distance_rule=inst.distance_rule, bks=None,
        meta=dict(inst.meta, parent=inst.name, parent_bks=inst.bks,
                  second_depot=pos.tolist(), position_rule=rule))
    out.meta.pop("published_routes", None)
    if inst.service is not None:
        out.service = np.concatenate([inst.service, [0.0]])
    if isinstance(trucks, str):
        if trucks == "copy":
            out.trucks = [k, k]
        elif trucks == "split":
            out.trucks = split_trucks(out, k)
        else:
            raise ValueError(trucks)
        out.meta["trucks_rule"] = trucks
    else:
        out.trucks = [int(t) for t in trucks]
        out.meta["trucks_rule"] = "imposée"
    if sum(out.trucks) * out.capacity < out.demand.sum():
        raise ValueError("flotte insuffisante pour la demande totale")
    return out


def second_depot_table(names, trucks="copy") -> list:
    """Tableau récapitulatif (une ligne par instance) : position du dépôt
    d'origine et du nouveau dépôt, camions de chaque dépôt, clients les plus
    proches de chaque dépôt et camions nécessaires pour eux."""
    from .readers import augerat
    rows = []
    for nm in names:
        one = augerat(nm)
        two = add_second_depot(one, trucks=trucks)
        near = two.nearest_depot()
        q = two.demand[1:two.n + 1]
        rows.append({
            "instance": nm, "clients": one.n, "Q": one.capacity, "k": one.trucks[0],
            "optimum_1_depot": one.bks,
            "depot_1_x": one.coords[0, 0], "depot_1_y": one.coords[0, 1],
            "depot_2_x": two.coords[-1, 0], "depot_2_y": two.coords[-1, 1],
            "camions_depot_1": two.trucks[0], "camions_depot_2": two.trucks[1],
            "clients_plus_proches_1": int((near == 0).sum()),
            "clients_plus_proches_2": int((near == 1).sum()),
            "camions_min_1": math.ceil(q[near == 0].sum() / two.capacity - 1e-9),
            "camions_min_2": math.ceil(q[near == 1].sum() / two.capacity - 1e-9),
        })
    return rows
