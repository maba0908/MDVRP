"""
Vérification indépendante d'une solution MDVRP / MDVRPTW.

Ce module ne réutilise AUCUN code des solveurs : il sert de juge commun au PLNE
et à la recherche tabou. Il contrôle :

  1. chaque client est livré exactement une fois (ni oubli, ni doublon) ;
  2. la capacité de chaque camion est respectée ;
  3. la flotte de chaque dépôt est respectée (pas plus de tournées que de camions) ;
  4. chaque camion part d'un dépôt et revient à CE dépôt ;
  5. si l'instance en a : la durée maximale des tournées et les fenêtres de temps
     (attente autorisée en cas d'avance, aucun retard toléré).

Format d'une solution (le même pour toute l'équipe) : une liste de tournées,
chaque tournée étant la suite COMPLÈTE des lieux visités, dépôt compris :
    [[0, 12, 5, 33, 0], [101, 7, 2, 101], ...]
Les formes {"depot": d, "clients": [...]} (d = numéro 0..m-1 du dépôt) sont
aussi acceptées ; voir normalize_solution.
"""
from dataclasses import dataclass, field

import numpy as np

from .instance import INF, MDVRPInstance

TOL = 1e-6


@dataclass
class CheckReport:
    """Résultat d'une vérification."""
    feasible: bool
    cost: float
    errors: list = field(default_factory=list)
    n_routes: int = 0
    routes_per_depot: list = field(default_factory=list)
    loads: list = field(default_factory=list)
    durations: list = field(default_factory=list)

    def __bool__(self):
        return self.feasible

    def __str__(self):
        head = (f"{'RÉALISABLE' if self.feasible else 'NON RÉALISABLE'} — coût {self.cost:.2f}, "
                f"{self.n_routes} tournées {self.routes_per_depot}")
        return head + "".join(f"\n  - {e}" for e in self.errors[:20])


def normalize_solution(inst: MDVRPInstance, solution) -> list:
    """Ramène les formats acceptés à des chemins complets [dépôt, ..., dépôt].

    * [[0, 3, 7, 0], ...]                    -> inchangé
    * [{"depot": 1, "clients": [3, 7]}, ...] -> [[lieu du dépôt 1, 3, 7, lieu du dépôt 1], ...]
    * (routes, depots) avec routes = [[3, 7], ...] et depots = [1, ...]
      (sortie de la recherche tabou du projet : res.routes, res.depots)
    """
    if isinstance(solution, tuple) and len(solution) == 2:
        routes, depots = solution
        return [[inst.depots[d]] + list(r) + [inst.depots[d]] for r, d in zip(routes, depots)]
    out = []
    for r in solution:
        if isinstance(r, dict):
            loc = inst.depots[int(r["depot"])]
            out.append([loc] + [int(c) for c in r["clients"]] + [loc])
        else:
            out.append([int(v) for v in r])
    return out


def route_schedule(inst: MDVRPInstance, path: list) -> tuple:
    """Horaires d'une tournée (départ au plus tôt, attente si avance).

    Renvoie (retard maximal sur une fenêtre, durée minimale de la tournée).
    La durée minimale tient compte d'un départ retardé du dépôt quand il évite
    des attentes sans créer de retard (Savelsbergh, 1992)."""
    nloc = len(inst.demand)
    e = inst.tw_early if inst.tw_early is not None else np.zeros(nloc)
    lt = inst.tw_late if inst.tw_late is not None else np.full(nloc, INF)
    s = inst.service if inst.service is not None else np.zeros(nloc)
    d = inst.dist
    depart = e[path[0]]
    t, late, waits, slack = depart, 0.0, 0.0, INF
    for a, b in zip(path[:-1], path[1:]):
        arrival = t + s[a] + d[a, b]
        t = max(arrival, e[b])
        waits += t - arrival
        late = max(late, t - lt[b])
        slack = min(slack, waits + lt[b] - t)
    shift = max(0.0, min(slack, waits))
    return late, t - depart - shift


def check_solution(inst: MDVRPInstance, solution, declared_cost: float | None = None,
                   tol: float = TOL) -> CheckReport:
    """Vérifie une solution et recalcule son coût (somme des distances)."""
    paths = normalize_solution(inst, solution)
    errors = []
    depots = inst.depots
    is_depot = np.zeros(len(inst.demand), dtype=bool)
    is_depot[depots] = True
    seen = np.zeros(inst.n + 1, dtype=int)
    per_depot = [0] * inst.m
    total, loads, durations = 0.0, [], []
    for k, path in enumerate(paths):
        if len(path) < 3:
            errors.append(f"tournée {k} : vide ou trop courte {path}")
            continue
        start, end, inner = path[0], path[-1], path[1:-1]
        bad = [v for v in path if not 0 <= v < len(inst.demand)]
        if bad:
            errors.append(f"tournée {k} : lieux inconnus {bad}")
            continue
        if not is_depot[start]:
            errors.append(f"tournée {k} : ne part pas d'un dépôt (lieu {start})")
            continue
        if end != start:
            errors.append(f"tournée {k} : part du dépôt {inst.depot_index(start) + 1} "
                          f"(lieu {start}) mais finit au lieu {end}")
        if any(is_depot[v] for v in inner):
            errors.append(f"tournée {k} : passe par un dépôt en cours de route")
        d = inst.depot_index(start)
        per_depot[d] += 1
        for c in inner:
            if not is_depot[c]:
                seen[c] += 1
        load = float(inst.demand[inner].sum())
        loads.append(load)
        if load > inst.capacity + tol:
            errors.append(f"tournée {k} (dépôt {d + 1}) : charge {load:g} > Q = {inst.capacity:g}")
        total += float(sum(inst.dist[a, b] for a, b in zip(path[:-1], path[1:])))
        if inst.has_time_windows or inst.has_duration_limit:
            late, dur = route_schedule(inst, path)
            durations.append(dur)
            if late > tol:
                errors.append(f"tournée {k} (dépôt {d + 1}) : fenêtre de temps dépassée de {late:.2f}")
            if inst.max_duration is not None and dur > inst.max_duration[d] + tol:
                errors.append(f"tournée {k} (dépôt {d + 1}) : durée {dur:.2f} > "
                              f"D = {inst.max_duration[d]:g}")
    missing = [c for c in inst.customers if seen[c] == 0]
    twice = [c for c in inst.customers if seen[c] > 1]
    if missing:
        errors.append(f"{len(missing)} client(s) jamais livré(s) : {missing[:15]}")
    if twice:
        errors.append(f"{len(twice)} client(s) livré(s) plusieurs fois : {twice[:15]}")
    for d in range(inst.m):
        if per_depot[d] > inst.trucks[d]:
            errors.append(f"dépôt {d + 1} : {per_depot[d]} tournées pour {inst.trucks[d]} camions")
    if declared_cost is not None and abs(declared_cost - total) > max(0.01, 1e-6 * total):
        errors.append(f"coût annoncé {declared_cost:.2f} ≠ coût recalculé {total:.2f}")
    return CheckReport(feasible=not errors, cost=total, errors=errors, n_routes=sum(per_depot),
                       routes_per_depot=per_depot, loads=loads, durations=durations)


def gap(cost: float, ref: float) -> float:
    """Écart relatif (%) à une référence : 100 (coût - réf) / réf."""
    return 100.0 * (cost - ref) / ref
