"""Fichiers de solution au format JSON partagé par l'équipe.

    {
      "instance": "p04",
      "method": "recherche tabou" | "PLNE" | ...,
      "cost": 1001.04,                       # facultatif, revérifié à la lecture
      "routes": [[0, 12, 5, 0], [101, 7, 101], ...]   # chemins complets, dépôt compris
    }
"""
import json
import os

from .checker import check_solution, normalize_solution


def save_solution(path: str, inst, solution, method: str = "", extra: dict | None = None) -> dict:
    """Vérifie puis enregistre une solution ; renvoie le dictionnaire écrit."""
    paths = normalize_solution(inst, solution)
    rep = check_solution(inst, paths)
    data = {"instance": inst.name, "method": method, "cost": round(rep.cost, 6),
            "feasible": rep.feasible, "routes_per_depot": rep.routes_per_depot,
            "routes": paths}
    if extra:
        data.update(extra)
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    return data


def load_solution(path: str) -> dict:
    with open(path) as f:
        return json.load(f)
