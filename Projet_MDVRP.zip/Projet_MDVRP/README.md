# Projet MDVRP — groupe 2

## Démarrer dans VS Code

1. Extraire tout le ZIP dans un dossier.
2. Ouvrir ce dossier dans VS Code avec Fichier → Ouvrir le dossier.
3. Ouvrir Terminal → Nouveau terminal et installer les dépendances :

```bash
python -m pip install -r requirements.txt
```

4. Ouvrir `lancer.py` et cliquer sur Exécuter le fichier Python.

L'exécution par défaut utilise **p12**, avec un budget tabou de 10 secondes.
Elle crée les tournées vérifiées, l'historique et les graphiques dans `resultats/p12`.

Si le terminal reste ouvert après le calcul, fermer les fenêtres graphiques.

## Autres lancements

Depuis le dossier du projet :

```bash
python lancer.py --instance p05 --secondes 30
python lancer.py --instance p04_sous_10 --secondes 5
python lancer.py --instance p12 --sans-fenetre
```

`Demonstration.ipynb` fournit aussi un point d'entrée pour Jupyter.

## Ce qui a été réuni

- `donnees_mdvrp/` : lecteurs, données, vérificateur indépendant et graphiques de Lionel.
- `solveur_mdvrp.py` : construction et mouvements de Lilian, intégrés à la recherche tabou.
- `integration.py` : conversion des données et des solutions entre les deux formats.
- `lancer.py` : un lancement complet, sans modification manuelle des indices.
- `preparer_donnees.py` : inventaire et génération reproductible des 20 instances.
- `experiences.py` : lancement d'une campagne, répétitions et statistiques.
- `sources_equipe/` : sources reçues utiles pour suivre l'intégration.

## Données reçues

`data/cordeau/` contient les 33 instances classiques p01–p23 et pr01–pr10,
plus le fichier supplémentaire pfbo. Les données d'origine sont conservées.
Le README, la description du format et la licence fournis avec ces données
restent dans ce dossier. Source : https://github.com/fboliveira/MDVRP-Instances

L'inventaire complet est dans `inventaire_instances.csv`.
Seuls **p04, p05, p12** ont exactement deux dépôts et aucune durée maximale
parmi les fichiers reçus. Les autres ne sont pas utilisés dans la campagne.
Leur simple suppression de contraintes changerait le problème de référence.

## Premier lot de 20 instances

Le fichier `catalogue_20_instances.csv` décrit :

- 3 benchmarks complets : p04 (100 clients), p05 (100), p12 (80) ;
- 17 sous-instances : premiers 10, 20, 30, 40, 60, 80 clients de p04 et p05 ;
  premiers 10, 20, 30, 40, 60 clients de p12.

Chaque sous-instance garde les deux dépôts, leurs véhicules, la capacité et les
coordonnées du parent. Les JSON sont dans `data/preparees/`. Ils permettent
également à Arend de travailler sur exactement les mêmes données.

Ces sous-instances sont de nouveaux problèmes, sans BKS publiée héritée.
Elles sont liées à seulement trois géographies sources : cette dépendance
limite la diversité de la campagne. Les essais actuels étudient surtout la
variation de taille et l'ordre initial ; ils ne constituent pas encore
une étude complète des positions de dépôts et des paramètres tabou.

## Références et gaps

Le guide pédagogique de Sonia IKKEN, p. 2, fournit 750,03 pour p05 et 1318,95
pour p12. Ces valeurs sont indiquées comme références du guide, sans déclarer
leur optimalité prouvée. La publication d'origine devra être référencée dans
le rendu final.

La valeur p04 à 1001,04 présente dans le code reçu est décrite comme trouvée
par le projet, avec un fichier solution absent. Elle n'est donc pas reprise
comme référence publiée vérifiée. Aucun gap n'est calculé pour p04 ou pour
les sous-instances. Une valeur du projet ne doit pas devenir sa propre BKS.

Les résultats du PLNE d'Arend et ses bornes restent à ajouter.

## Premiers résultats fournis

`resultats/campagne/` contient les essais réellement exécutés :

- `protocole.json` : budgets, paramètres et environnement ;
- `resultats_bruts.csv` : un enregistrement par lancement, y compris les erreurs ;
- `statistiques.csv` : moyenne, écart-type, meilleur coût, temps et gaps disponibles ;
- `*.json` : tournées de chaque exécution validée, dans le format de Lionel.

Budget tabou : 3 secondes maximum, 1000 itérations maximum, stagnation après
250 itérations sans amélioration, durée tabou 7. Trois départs aléatoires
(graines 42, 43, 44) par instance. La construction initiale est chronométrée
séparément. Le nombre d'itérations peut varier avec la vitesse de la machine.
Le budget est contrôlé à l'intérieur de la boucle et peut être légèrement
dépassé par une opération en cours.

Ce sont des premiers essais, avec un budget court et sans calibration :
aucune garantie de faible gap ou de note n'est annoncée. Les écarts élevés
et les échecs sont conservés dans les tableaux.

## Relancer la campagne

```bash
python experiences.py --secondes 10 --repetitions 10
```

Attention : une nouvelle campagne remplace les fichiers de la précédente.
Copier le dossier de résultats avant de relancer pour garder les essais.

## Relier les résultats d'Arend

Les solutions à vérifier peuvent utiliser le format :

```json
{"instance":"p04_sous_10","method":"PLNE","cost":123.45,
 "routes":[[0,1,2,0],[11,3,4,5,6,7,8,9,10,11]]}
```

L'exemple décrit uniquement le format, pas une solution calculée.
Avec n clients et deux dépôts, les lieux sont : dépôt 1 = 0,
clients = 1..n, dépôt 2 = n+1. Le dépôt de départ doit apparaître au retour.
Pour comparer la qualité, demander également le statut du solveur, la borne
inférieure certifiée, le temps et le code du modèle exact.

## Périmètre et limites

Le solveur traite les distances symétriques, les capacités, les demandes
indivisibles et une flotte fixe par dépôt. Il ne traite pas les durées
maximales ni les fenêtres horaires. Les conversions refusent ces contraintes.

La matrice calculée par Lionel est conservée : aucune perte de l'arrondi
CVRPLIB lors de la conversion. Tous les résultats présentés passent son
vérificateur indépendant, avec recalcul du coût.

Le solveur explore encore beaucoup de mouvements ; les milliers de clients
n'ont pas été validés. L'initialisation peut échouer sans prouver que le
problème est infaisable. La recherche ne prouve pas l'optimalité.

La comparaison locale autonome dans `solveur_mdvrp.py` n'a pas de limite de
temps : les lanceurs de ce paquet utilisent directement le tabou borné.

## Changements apportés aux fichiers reçus

- Remplacement de la passerelle `tabu_vrp` absente par `to_solveur()`.
- Mise à l'écart des BKS non sourcées ; p05/p12 renvoient au guide.
- Ajout d'une passerelle de numérotation, d'un catalogue et des essais.
- Conservation des données originales et des sources reçues.
