"""Solveur MDVRP du groupe 2.
Base : données, construction et mouvements de Lilian.
Intégration : recherche tabou, contrôles, exports et graphiques.
Distances euclidiennes symétriques, capacités et flotte fixe par dépôt.

DÉMARRAGE
    Ouvrir ce fichier dans VS Code et cliquer sur Exécuter le fichier Python.
    L'exemple de Lilian (40 clients) se lance et crée le dossier resultats.
    Pour les graphiques : python -m pip install matplotlib

COMMANDES FACULTATIVES
    python solveur_mdvrp.py --exemple petit
    python solveur_mdvrp.py --secondes 30 --iterations 1000
    python solveur_mdvrp.py --instance donnees.json --sans-local
    python solveur_mdvrp.py --ordre random --seed 5

DONNÉES DE LIONEL
    inst = Instance(clients_xy=[...], demande=[...], depots_xy=[...],
                    vehicules_par_depot=[...], capacite=...)
    resultat = executer(inst)
    Le JSON utilise ces mêmes cinq noms de champs. Clients indexés 0, 1, ...
    (l'affichage montre C1, C2, ...). Le lecteur des benchmarks reste à brancher.

FICHIERS PRODUITS
    resume.csv : coûts et temps séparés des trois phases, paramètres.
    historique.csv : évolution de la recherche tabou.
    solutions.json : tournées initiales, locales et tabou, indices à partir de 0.
    tournees.png et convergence.png : graphiques si matplotlib est installé.
    Un nouveau lancement remplace ces fichiers : changer --sortie pour garder
    plusieurs expériences.

PÉRIMÈTRE
    Une tournée par véhicule, retour à son dépôt, demandes indivisibles.
    Pas de fenêtres horaires, de durée maximale ni de trafic temporel.
    La recherche locale de comparaison n'a pas de limite de temps : l'option
    --sans-local permet de la sauter sur de grandes instances.
    Le temps maximal concerne seulement la recherche tabou et peut être dépassé
    légèrement par une opération en cours. La construction est mesurée à part.
    Le meilleur résultat tabou n'est pas une preuve d'optimalité.
    Aucun gap n'est calculé sans une référence compatible.
    Avec --ordre demand, répéter le même lancement est déterministe (sauf arrêt
    temporel). Utiliser --ordre random et plusieurs graines pour varier le départ.
"""
from __future__ import annotations
import math
import random
import argparse
import csv
import json
import time
from pathlib import Path
from collections import Counter
from dataclasses import dataclass, field

EPS = 1e-9


# ----------------------------------------------------------------------
# Données
# ----------------------------------------------------------------------
@dataclass
class Instance: ## Regroupe toutes les données du problème
    clients_xy: list          # [(x, y), ...]
    demande: list              # demande de chaque client
    depots_xy: list           # [(x, y), ...]  (2 dépôts ici, mais générique)
    vehicules_par_depot: list  # nb de camions par dépôt, ex. [3, 3]
    capacite: float           # capacité d'un camion
    d: list = field(init=False) ## Table des distances

    def __post_init__(self):
        if not self.clients_xy or not self.depots_xy:
            raise ValueError("Il faut des clients et des dépôts.")
        if len(self.demande) != len(self.clients_xy):
            raise ValueError("Une demande est nécessaire pour chaque client.")
        if len(self.vehicules_par_depot) != len(self.depots_xy):
            raise ValueError("Indiquer la flotte de chaque dépôt.")
        if not math.isfinite(self.capacite) or self.capacite <= 0:
            raise ValueError("La capacité doit être positive et finie.")
        if any(not math.isfinite(q) or q <= 0 or q > self.capacite
               for q in self.demande):
            raise ValueError("Chaque demande doit être positive et au plus égale à Q.")
        if any(type(m) is not int or m < 0 for m in self.vehicules_par_depot):
            raise ValueError("Les effectifs doivent être des entiers positifs ou nuls.")
        if sum(self.demande) > sum(self.vehicules_par_depot) * self.capacite + EPS:
            raise ValueError("Capacité totale insuffisante.")
        if any(len(p) != 2 or not all(math.isfinite(v) for v in p)
               for p in list(self.clients_xy) + list(self.depots_xy)):
            raise ValueError("Les coordonnées doivent être deux nombres finis.")
        pts = list(self.clients_xy) + list(self.depots_xy)
        self.d = [[math.dist(a, b) for b in pts] for a in pts] ## Calcule la distance entre chaque points et les ajoute à d

    @property
    def n(self):
        return len(self.clients_xy)

    def dep_node(self, k): ## Permet de trouver l'indice du dépôt k dans la table des distances d
        return self.n + k


@dataclass
class Camion: ## Représente une tournée de camion
    depot: int                       # indice du dépôt (0 ou 1)
    clients: list = field(default_factory=list)
    chargement: float = 0.0                


@dataclass
class Solution:
    routes: list                     # une route par camion (vides autorisées)

    def cost(self, inst): ## Distance totale parcourue par l'ensemble des camions
        return sum(route_cost(inst, r) for r in self.routes)

    def copy(self): ## Permet d'explorer de nouvelles solutions sans modifier l'initiale
        return Solution([Camion(r.depot, r.clients[:], r.chargement) for r in self.routes])


def route_cost(inst, r): ## Calcule la distance d'un camion
    if not r.clients:
        return 0.0
    dep = inst.dep_node(r.depot)
    d = inst.d
    c = r.clients
    total = d[dep][c[0]] + d[c[-1]][dep]
    for a, b in zip(c, c[1:]):
        total += d[a][b]
    return total


def _prev(inst, r, i):
    return r.clients[i - 1] if i > 0 else inst.dep_node(r.depot)


def _next(inst, r, i):
    return r.clients[i + 1] if i + 1 < len(r.clients) else inst.dep_node(r.depot)


# ----------------------------------------------------------------------
# 1) Solution initiale : insertion la moins chère sur TOUTES les tournées
#    (donc des deux dépôts). Respecte capacité et nombre de camions car
#    on ne dispose que de vehicules_par_depot[k] tournées par dépôt.
# ----------------------------------------------------------------------
def initial_solution(inst: Instance, order="demand", seed=42) : ## Créé le nbr de camions vide déf dans instance
    routes = [Camion(k) for k, nb in enumerate(inst.vehicules_par_depot) for _ in range(nb)]
    sol = Solution(routes)
    d = inst.d

    if order not in ("demand", "random", "input"):
        raise ValueError("order : demand, random ou input")
    clients = list(range(inst.n))
    if order == "demand":        
        clients.sort(key=lambda c: -inst.demande[c]) # tri décroissant (gros clients plus dur à placer)
    elif order == "random":
        random.Random(seed).shuffle(clients) # Mélange aléatoire des clients pour obtenir une solution initiale nouvelle

    for c in clients:
        best = None  # (delta, route, position)
        for r in routes:
            if r.chargement + inst.demande[c] > inst.capacite + EPS:
                continue
            dep = inst.dep_node(r.depot)
            for pos in range(len(r.clients) + 1):
                p = r.clients[pos - 1] if pos > 0 else dep # Point avant le client à insérer
                q = r.clients[pos] if pos < len(r.clients) else dep # Point après le client à insérer
                delta = d[p][c] + d[c][q] - d[p][q] # Distance supplémentaire dûe à l'insertion d'un client
                if best is None or delta < best[0]:
                    best = (delta, r, pos)
        if best is None:
            raise ValueError(
                f"Client {c} impossible à placer : pas assez de capacité/véhicules "
                f"(essayer un autre ordre ; cet échec ne prouve pas l’infaisabilité)."
            )
        _, r, pos = best
        r.clients.insert(pos, c)
        r.chargement += inst.demande[c]
    return sol


# ----------------------------------------------------------------------
# 2) Mouvements. Chaque générateur renvoie des tuples (delta, type, params).
#    delta < 0  <=>  amélioration. Les routes sont désignées par leur indice
#    dans sol.routes ; l'inter-dépôt est automatique (route.depot diffère).
# ----------------------------------------------------------------------
def relocate_moves(inst, sol):
    """Déplace un client vers une autre position (autre tournée ou même tournée)."""
    d = inst.d
    R = sol.routes
    for a, r1 in enumerate(R):
        for i, c in enumerate(r1.clients):
            p, q = _prev(inst, r1, i), _next(inst, r1, i)
            gain = d[p][c] + d[c][q] - d[p][q]
            for b, r2 in enumerate(R):
                if a == b:
                    # intra-tournée : on recalcule sur la liste modifiée
                    base = route_cost(inst, r1)
                    rest = r1.clients[:i] + r1.clients[i + 1:]
                    for j in range(len(rest) + 1):
                        if j == i:
                            continue
                        new = Camion(r1.depot, rest[:j] + [c] + rest[j:])
                        yield (route_cost(inst, new) - base, "relocate", (a, i, b, j))
                    continue
                if r2.chargement + inst.demande[c] > inst.capacite + EPS:
                    continue
                dep2 = inst.dep_node(r2.depot)
                for j in range(len(r2.clients) + 1):
                    p2 = r2.clients[j - 1] if j > 0 else dep2
                    q2 = r2.clients[j] if j < len(r2.clients) else dep2
                    add = d[p2][c] + d[c][q2] - d[p2][q2]
                    yield (add - gain, "relocate", (a, i, b, j))


def swap_moves(inst, sol):
    """Échange deux clients de deux tournées différentes (dépôts identiques ou non)."""
    d = inst.d
    R = sol.routes
    for a in range(len(R)):
        for b in range(a + 1, len(R)):
            r1, r2 = R[a], R[b]
            for i, c1 in enumerate(r1.clients):
                for j, c2 in enumerate(r2.clients):
                    if r1.chargement - inst.demande[c1] + inst.demande[c2] > inst.capacite + EPS:
                        continue
                    if r2.chargement - inst.demande[c2] + inst.demande[c1] > inst.capacite + EPS:
                        continue
                    p1, q1 = _prev(inst, r1, i), _next(inst, r1, i)
                    p2, q2 = _prev(inst, r2, j), _next(inst, r2, j)
                    delta = (d[p1][c2] + d[c2][q1] - d[p1][c1] - d[c1][q1]
                             + d[p2][c1] + d[c1][q2] - d[p2][c2] - d[c2][q2])
                    yield (delta, "swap", (a, i, b, j))


def two_opt_moves(inst, sol):
    """Inverse un segment de visites à l'intérieur d'une tournée (2-opt)."""
    d = inst.d
    for a, r in enumerate(sol.routes):
        m = len(r.clients)
        for i in range(m - 1):
            for j in range(i + 1, m):
                p, q = _prev(inst, r, i), _next(inst, r, j)
                ci, cj = r.clients[i], r.clients[j]
                delta = d[p][cj] + d[ci][q] - d[p][ci] - d[cj][q]
                yield (delta, "two_opt", (a, i, j))


def all_moves(inst, sol):
    yield from relocate_moves(inst, sol)
    yield from swap_moves(inst, sol)
    yield from two_opt_moves(inst, sol)


# ----------------------------------------------------------------------
# 3) Application d'un mouvement (modifie la solution en place)
# ----------------------------------------------------------------------
def apply_move(inst, sol, move):
    _, kind, prm = move # Distribue les éléments (delta, type_de_mouvement, paramètres) du mouvement à _, kind et prm
    R = sol.routes
    if kind == "relocate":
        tournee1, i, tournee2, j = prm # Distribue les paramètres du mouvement (numéro_tournée_a, position_du_client_dans_la_tournée_a, numéro_tournée_b, position_dans_la_tournée_b)
        c = R[tournee1].clients.pop(i)
        R[tournee2].clients.insert(j, c)
        if tournee1 != tournee2:
            R[tournee1].chargement -= inst.demande[c]
            R[tournee2].chargement += inst.demande[c]
    elif kind == "swap":
        tournee1, i, tournee2, j = prm
        c1, c2 = R[tournee1].clients[i], R[tournee2].clients[j]
        R[tournee1].clients[i], R[tournee2].clients[j] = c2, c1
        R[tournee1].chargement += inst.demande[c2] - inst.demande[c1]
        R[tournee2].chargement += inst.demande[c1] - inst.demande[c2]
    elif kind == "two_opt":
        tournee, i, j = prm
        R[tournee].clients[i:j + 1] = reversed(R[tournee].clients[i:j + 1])
    else:
        raise ValueError(kind)


# ----------------------------------------------------------------------
# 4) Descente locale : comparaison avec la recherche tabou
# ----------------------------------------------------------------------
def recherche_locale(inst, sol, best_improvement=True):
    sol = sol.copy()
    while True:
        best = None
        for mv in all_moves(inst, sol):
            if mv[0] < -EPS and (best is None or mv[0] < best[0]): # Recherche du meilleur mouvement à faire
                best = mv
                if not best_improvement:
                    break
        if best is None:
            return sol
        apply_move(inst, sol, best)



# ----------------------------------------------------------------------
# 5) Vérification complète (ne dépend pas des assert de Python)
# ----------------------------------------------------------------------
def check(inst, sol):
    """Lever ValueError si la solution est invalide, sinon renvoyer True."""
    flotte = Counter()
    visites = []
    for r in sol.routes:
        if type(r.depot) is not int or not 0 <= r.depot < len(inst.depots_xy):
            raise ValueError("Dépôt inconnu dans une tournée.")
        flotte[r.depot] += 1
        for c in r.clients:
            if type(c) is not int or not 0 <= c < inst.n:
                raise ValueError("Identifiant de client incorrect.")
        charge = sum(inst.demande[c] for c in r.clients)
        if not math.isfinite(r.chargement) or abs(charge - r.chargement) > 1e-6:
            raise ValueError("La charge enregistrée ne correspond pas aux clients.")
        if charge > inst.capacite + EPS:
            raise ValueError("Capacité dépassée.")
        visites.extend(r.clients)
    if Counter(visites) != Counter(range(inst.n)):
        raise ValueError("Client oublié ou livré plusieurs fois.")
    # Une route représente un véhicule disponible, même si elle est vide.
    if any(flotte[k] != nb for k, nb in enumerate(inst.vehicules_par_depot)):
        raise ValueError("Le nombre de véhicules disponibles a changé.")
    # Le dépôt est conservé dans Camion ; route_cost ajoute départ et retour.
    return True


def construire_initiale(inst, seed=42, essais=100, ordre="demand"):
    """Réessayer la construction avec d'autres ordres en cas de blocage."""
    if essais < 1:
        raise ValueError("Il faut au moins un essai de construction.")
    for essai in range(essais):
        try:
            sol = initial_solution(inst, ordre if essai == 0 else "random",
                                   seed + essai)
            check(inst, sol)
            return sol
        except ValueError:
            pass
    raise ValueError("Construction bloquée : aucune solution initiale trouvée. "
                     "Cela ne prouve pas que l'instance est infaisable.")


# ----------------------------------------------------------------------
# 6) Mémoire tabou : interdire de réintroduire les arêtes retirées
# ----------------------------------------------------------------------
def _aretes(inst, route):
    """Arêtes non orientées, avec multiplicité, pour une tournée."""
    if not route.clients:
        return Counter()
    dep = inst.dep_node(route.depot)
    trajet = [dep] + route.clients + [dep]
    return Counter((min(a, b), max(a, b)) for a, b in zip(trajet, trajet[1:]))


def _changement_aretes(inst, sol, move, avant):
    """Examiner uniquement les routes touchées, sans copier toute la solution."""
    _, kind, params = move
    indices = {params[0]} if kind == "two_opt" else {params[0], params[2]}
    routes = {i: Camion(sol.routes[i].depot, sol.routes[i].clients[:],
                         sol.routes[i].chargement) for i in indices}
    if kind == "relocate":
        a, i, b, j = params
        c = routes[a].clients.pop(i)
        routes[b].clients.insert(j, c)
    elif kind == "swap":
        a, i, b, j = params
        routes[a].clients[i], routes[b].clients[j] = (
            routes[b].clients[j], routes[a].clients[i])
    else:
        a, i, j = params
        routes[a].clients[i:j + 1] = reversed(routes[a].clients[i:j + 1])
    retires, ajoutes = set(), set()
    for i, route in routes.items():
        apres = _aretes(inst, route)
        retires.update((i, *e) for e in (avant[i] - apres))
        ajoutes.update((i, *e) for e in (apres - avant[i]))
    return retires, ajoutes


def recherche_tabou(inst, sol, iterations_max=300, duree_tabou=7,
                     stagnation_max=100, temps_max=10.0):
    """Choisir le meilleur voisin admissible et conserver le meilleur résultat.

    Une arête retirée est interdite de réintroduction pendant duree_tabou
    itérations. Aspiration : lever l'interdiction pour un nouveau record.
    En cas de blocage par la mémoire, la vider et reprendre la recherche.
    La limite de temps est vérifiée pendant l'examen des mouvements.
    """
    if (type(iterations_max) is not int or iterations_max < 0
            or type(duree_tabou) is not int or duree_tabou < 0
            or type(stagnation_max) is not int or stagnation_max < 1
            or not math.isfinite(temps_max) or temps_max < 0):
        raise ValueError("Paramètres de recherche incorrects.")
    check(inst, sol)
    courante = sol.copy()
    meilleure = sol.copy()
    cout = courante.cost(inst)
    record = cout
    debut = time.perf_counter()
    temps_record = 0.0
    tabou = {}
    stagnation = 0
    blocages = 0
    raison = "iterations_max"
    historique = [{"iteration": 0, "temps_s": 0.0, "cout_courant": cout,
                   "meilleur_cout": record, "mouvement": "depart"}]
    for iteration in range(1, iterations_max + 1):
        if time.perf_counter() - debut >= temps_max:
            raison = "temps_max"
            break
        tabou = {cle: fin for cle, fin in tabou.items() if fin >= iteration}
        avant = [_aretes(inst, r) for r in courante.routes]
        choix, interdites = None, None
        valeur = float("inf")
        secours, retires_secours = None, None
        valeur_secours = float("inf")
        limite = False
        for move in all_moves(inst, courante):
            if time.perf_counter() - debut >= temps_max:
                limite = True
                break
            candidat = cout + move[0]
            # Les arêtes ne sont examinées que si ce mouvement peut être retenu.
            if candidat >= valeur - EPS and candidat >= valeur_secours - EPS:
                continue
            retires, ajoutes = _changement_aretes(inst, courante, move, avant)
            # Inverser toute une tournée symétrique garde les mêmes arêtes.
            if not retires and not ajoutes:
                continue
            if candidat < valeur_secours - EPS:
                secours, retires_secours = move, retires
                valeur_secours = candidat
            est_tabou = any(cle in tabou for cle in ajoutes)
            aspiration = candidat < record - EPS
            if (not est_tabou or aspiration) and candidat < valeur - EPS:
                choix, interdites, valeur = move, retires, candidat
        if choix is None:
            if secours is None:
                raison = "temps_max" if limite else "aucun_mouvement"
                break
            tabou.clear()
            blocages += 1
            choix, interdites = secours, retires_secours
        apply_move(inst, courante, choix)
        check(inst, courante)
        # Recalcul exact après le seul mouvement appliqué, pour éviter la dérive.
        cout = courante.cost(inst)
        for cle in interdites:
            tabou[cle] = iteration + duree_tabou
        if cout < record - EPS:
            meilleure, record = courante.copy(), cout
            temps_record = time.perf_counter() - debut
            stagnation = 0
        else:
            stagnation += 1
        historique.append({"iteration": iteration,
                           "temps_s": time.perf_counter() - debut,
                           "cout_courant": cout, "meilleur_cout": record,
                           "mouvement": choix[1]})
        if limite:
            raison = "temps_max"
            break
        if stagnation >= stagnation_max:
            raison = "stagnation"
            break
    check(inst, meilleure)
    return {"solution": meilleure, "cout": record,
            "temps_s": time.perf_counter() - debut,
            "temps_meilleure_s": temps_record,
            "iterations": len(historique) - 1, "arret": raison,
            "levees_tabou": blocages, "historique": historique}


# ----------------------------------------------------------------------
# 7) Exemples et lecture d'une instance JSON
# ----------------------------------------------------------------------
def exemple_petit():
    return Instance(clients_xy=[(1, 2), (2, 1), (3, 3), (8, 1), (9, 3), (7, 2)],
                    demande=[2, 3, 2, 2, 3, 2], depots_xy=[(0, 0), (10, 0)],
                    vehicules_par_depot=[1, 1], capacite=10)


def exemple_lilian(seed=1):
    rng = random.Random(seed)
    return Instance(clients_xy=[(rng.uniform(0, 100), rng.uniform(0, 100))
                                for _ in range(40)],
                    demande=[rng.randint(1, 10) for _ in range(40)],
                    depots_xy=[(20, 20), (80, 80)],
                    vehicules_par_depot=[4, 4], capacite=60)


def charger_instance(chemin):
    """JSON au format des cinq arguments d'Instance. Voir le README."""
    donnees = json.loads(Path(chemin).read_text(encoding="utf-8"))
    return Instance(**{k: donnees[k] for k in (
        "clients_xy", "demande", "depots_xy", "vehicules_par_depot", "capacite")})


def afficher_solution(inst, sol, titre):
    print(f"\n{titre} : {sol.cost(inst):.2f}")
    for i, r in enumerate(sol.routes, 1):
        clients = " -> ".join(f"C{c + 1}" for c in r.clients)
        trajet = f"D{r.depot + 1} -> {clients} -> D{r.depot + 1}" if clients else "inutilisé"
        print(f"  Camion {i} | {trajet} | charge {r.chargement:g}/{inst.capacite:g}")


# ----------------------------------------------------------------------
# 8) Exports et graphiques
# ----------------------------------------------------------------------
def tracer(inst, initiale, resultat, dossier, afficher=True):
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Graphiques indisponibles. Installer matplotlib : python -m pip install matplotlib")
        return
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, sol, titre in zip(axes, [initiale, resultat["solution"]],
                             ["Solution initiale", "Recherche tabou"]):
        for k, (x, y) in enumerate(inst.depots_xy):
            couleur = f"C{k % 10}"
            ax.scatter(x, y, s=130, marker="s", color=couleur, label=f"D{k + 1}")
            ax.annotate(f"D{k + 1}", (x, y), xytext=(5, 6), textcoords="offset points")
            for r in sol.routes:
                if r.depot != k or not r.clients:
                    continue
                pts = [(x, y)] + [inst.clients_xy[c] for c in r.clients] + [(x, y)]
                ax.plot([p[0] for p in pts], [p[1] for p in pts], "o-",
                        color=couleur, markersize=3, alpha=.7)
        if inst.n <= 50:
            for c, p in enumerate(inst.clients_xy):
                ax.annotate(f"C{c + 1}", p, fontsize=7)
        ax.set_title(f"{titre} : {sol.cost(inst):.2f}")
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.grid(alpha=.2)
        ax.legend()
    fig.tight_layout()
    fig.savefig(dossier / "tournees.png", dpi=150)
    fig2, ax = plt.subplots(figsize=(9, 4))
    h = resultat["historique"]
    ax.plot([r["temps_s"] for r in h], [r["cout_courant"] for r in h],
            label="Coût courant", alpha=.6)
    ax.plot([r["temps_s"] for r in h], [r["meilleur_cout"] for r in h],
            label="Meilleur coût", linewidth=2)
    ax.set_xlabel("Temps écoulé (s)")
    ax.set_ylabel("Distance")
    ax.set_title("Évolution de la recherche tabou")
    ax.grid(alpha=.2)
    ax.legend()
    fig2.tight_layout()
    fig2.savefig(dossier / "convergence.png", dpi=150)
    if afficher:
        plt.show()
    else:
        plt.close(fig)
        plt.close(fig2)


def executer(inst, dossier="resultats", seed=42, iterations=300, tenure=7,
             stagnation=100, secondes=10, ordre="demand", local=True,
             graphiques=True, afficher=True):
    """Lancer construction, comparaison locale, tabou et exports."""
    dossier = Path(dossier)
    dossier.mkdir(parents=True, exist_ok=True)
    debut = time.perf_counter()
    initiale = construire_initiale(inst, seed=seed, ordre=ordre)
    temps_initial = time.perf_counter() - debut
    locale, temps_local = None, None
    if local:
        debut = time.perf_counter()
        locale = recherche_locale(inst, initiale)
        temps_local = time.perf_counter() - debut
        check(inst, locale)
    # Même solution de départ pour les deux méthodes.
    resultat = recherche_tabou(inst, initiale, iterations, tenure, stagnation, secondes)
    cout_initial = initiale.cost(inst)
    afficher_solution(inst, initiale, "Solution initiale")
    if locale is not None:
        afficher_solution(inst, locale, "Recherche locale")
    afficher_solution(inst, resultat["solution"], "Recherche tabou")
    resume = {"clients": inst.n, "depots": len(inst.depots_xy), "seed": seed,
              "ordre_initial": ordre, "iterations_max": iterations,
              "duree_tabou": tenure, "stagnation_max": stagnation,
              "temps_max_s": secondes, "cout_initial": cout_initial,
              "temps_initial_s": temps_initial,
              "cout_local": locale.cost(inst) if locale is not None else None,
              "temps_local_s": temps_local, "cout_tabou": resultat["cout"],
              "temps_tabou_s": resultat["temps_s"],
              "temps_meilleure_s": resultat["temps_meilleure_s"],
              "iterations": resultat["iterations"], "arret": resultat["arret"],
              "levees_tabou": resultat["levees_tabou"], "valide": True,
              "amelioration_pct": 100 * (cout_initial - resultat["cout"]) / cout_initial
              if cout_initial > EPS else 0.0}
    for nom, lignes in (("resume.csv", [resume]),
                        ("historique.csv", resultat["historique"])):
        with (dossier / nom).open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(lignes[0]))
            writer.writeheader()
            writer.writerows(lignes)
    def routes_json(sol):
        return [dict(depot=r.depot, clients=r.clients, chargement=r.chargement)
                for r in sol.routes]
    contenu = {"resume": resume, "initiale": routes_json(initiale),
               "locale": routes_json(locale) if locale is not None else None,
               "tabou": routes_json(resultat["solution"])}
    (dossier / "solutions.json").write_text(
        json.dumps(contenu, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nSolution vérifiée | amélioration : {resume['amelioration_pct']:.2f} %")
    print(f"Tabou : {resultat['temps_s']:.3f} s | {resultat['iterations']} itérations")
    print(f"Arrêt : {resultat['arret']} | fichiers : {dossier.resolve()}")
    if graphiques:
        tracer(inst, initiale, resultat, dossier, afficher)
    return resultat


def main():
    parser = argparse.ArgumentParser(description="MDVRP : base Lilian + recherche tabou")
    parser.add_argument("--exemple", choices=["petit", "lilian"], default="lilian")
    parser.add_argument("--instance", help="Instance JSON au format du README")
    parser.add_argument("--sortie", default="resultats")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--iterations", type=int, default=300)
    parser.add_argument("--tabou", type=int, default=7)
    parser.add_argument("--stagnation", type=int, default=100)
    parser.add_argument("--secondes", type=float, default=10)
    parser.add_argument("--ordre", choices=["demand", "random", "input"], default="demand")
    parser.add_argument("--sans-local", action="store_true",
                        help="Ne pas lancer la comparaison locale (sans limite de temps)")
    parser.add_argument("--sans-graphiques", action="store_true")
    parser.add_argument("--sans-fenetre", action="store_true")
    args = parser.parse_args()
    inst = charger_instance(args.instance) if args.instance else (
        exemple_petit() if args.exemple == "petit" else exemple_lilian())
    executer(inst, args.sortie, args.seed, args.iterations, args.tabou,
             args.stagnation, args.secondes, args.ordre, not args.sans_local,
             not args.sans_graphiques, not args.sans_fenetre)


if __name__ == "__main__":
    main()
