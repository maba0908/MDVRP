"""Première campagne de 20 instances ; résultats bruts et statistiques."""
from pathlib import Path
import argparse,csv,json,time,statistics,platform
from donnees_mdvrp import MDVRPInstance,save_solution
from integration import convertir_instance,exporter_routes,verifier_commun
from solveur_mdvrp import construire_initiale,recherche_tabou
from preparer_donnees import ROOT,preparer

def ecrire(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)

def campagne(secondes=3,repetitions=3):
    catalogue=preparer();out=ROOT/'resultats'/'campagne';out.mkdir(parents=True,exist_ok=True)
    (out/'protocole.json').write_text(json.dumps({'instances':20,'repetitions':repetitions,
       'temps_tabou_max_s':secondes,'iterations_max':1000,'stagnation_max':250,'duree_tabou':7,
       'initialisation':'insertion, ordre aléatoire ; essais de réparation au besoin',
       'graines':[42+i for i in range(repetitions)],'python':platform.python_version(),
       'machine':platform.platform(),'phase':'premiers essais, réglages non optimisés'},indent=2,ensure_ascii=False))
    lignes=[]
    for no,item in enumerate(catalogue,1):
        source=MDVRPInstance.from_json(str(ROOT/item['fichier']))
        cible=convertir_instance(source)
        for run in range(repetitions):
            seed=42+run
            row={'instance':source.name,'famille':item['famille'],'parent':item['parent'],
                 'clients':source.n,'seed':seed,'valide':False,'erreur':'',
                 'cout_initial':None,'cout_tabou':None,'temps_initial_s':None,
                 'temps_tabou_s':None,'temps_meilleure_s':None,'iterations':None,
                 'arret':'','reference':source.bks,'gap_reference_pct':None}
            try:
                debut=time.perf_counter();s=construire_initiale(cible,seed=seed,ordre='random')
                row['temps_initial_s']=time.perf_counter()-debut
                verifier_commun(source,cible,s)
                r=recherche_tabou(cible,s,iterations_max=1000,duree_tabou=7,
                                  stagnation_max=250,temps_max=secondes)
                rep=verifier_commun(source,cible,r['solution'])
                row.update(valide=True,cout_initial=s.cost(cible),cout_tabou=rep.cost,
                  temps_tabou_s=r['temps_s'],temps_meilleure_s=r['temps_meilleure_s'],
                  iterations=r['iterations'],arret=r['arret'])
                if source.bks:row['gap_reference_pct']=100*(rep.cost-source.bks)/source.bks
                save_solution(str(out/f'{source.name}_seed{seed}.json'),source,
                    exporter_routes(source,r['solution']),method='recherche tabou',extra={'seed':seed})
            except ValueError as exc:row['erreur']=str(exc)
            lignes.append(row);ecrire(out/'resultats_bruts.csv',lignes)
            print(f'{no}/20 {source.name} seed={seed}: '+
                 (f"cout {row['cout_tabou']:.2f}" if row['valide'] else row['erreur']),flush=True)
    stats=[]
    for item in catalogue:
        rows=[r for r in lignes if r['instance']==item['instance'] and r['valide']]
        def moy(k):return statistics.mean(r[k] for r in rows) if rows else None
        couts=[r['cout_tabou'] for r in rows]
        stats.append({'instance':item['instance'],'famille':item['famille'],'clients':item['clients'],
          'essais_valides':len(rows),'essais_total':repetitions,
          'meilleur_cout':min(couts) if rows else None,'cout_moyen':moy('cout_tabou'),
          'ecart_type_cout':statistics.stdev(couts) if len(couts)>1 else None,
          'temps_initial_moyen_s':moy('temps_initial_s'),'temps_tabou_moyen_s':moy('temps_tabou_s'),
          'temps_meilleure_moyen_s':moy('temps_meilleure_s'),
          'reference':item['reference'],'gap_moyen_pct':moy('gap_reference_pct') if item['reference'] else None})
    ecrire(out/'statistiques.csv',stats)
    return stats

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--secondes',type=float,default=3)
    p.add_argument('--repetitions',type=int,default=3);a=p.parse_args()
    if a.secondes<0 or a.repetitions<1:p.error('Budgets invalides')
    campagne(a.secondes,a.repetitions)
