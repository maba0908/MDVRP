"""Inventorier les fichiers reçus et préparer 20 instances à deux dépôts."""
from pathlib import Path
import csv
from donnees_mdvrp import read_cordeau
from integration import sous_instance

ROOT=Path(__file__).resolve().parent


def preparer():
    sortie=ROOT/'data'/'preparees';sortie.mkdir(exist_ok=True)
    inventaire=[];catalogue=[]
    for path in sorted((ROOT/'data'/'cordeau').iterdir()):
        if not (path.name.startswith('p') and path.name not in ('README.md',)):
            continue
        try:
            inst=read_cordeau(str(path),name=path.name)
        except (ValueError,IndexError):
            continue
        compatible=inst.m==2 and not inst.has_duration_limit and not inst.has_time_windows
        inventaire.append({'instance':inst.name,'clients':inst.n,'depots':inst.m,
          'flotte':str(inst.trucks),'capacite':inst.capacity,
          'duree_max':str(inst.max_duration),'compatible_modele':compatible,
          'motif':'compatible' if compatible else
           ('plus de deux depots' if inst.m!=2 else 'duree maximale imposee')})
    for nom in ['p04','p05','p12']:
        inst=read_cordeau(str(ROOT/'data'/'cordeau'/nom),name=nom)
        inst.meta['reference_source']='Guide Sonia IKKEN, octobre 2026, p. 2' if inst.bks else None
        inst.to_json(str(sortie/f'{nom}.json'))
        catalogue.append({'instance':nom,'famille':'benchmark_original','parent':nom,
           'clients':inst.n,'depots':inst.m,'reference':inst.bks,
           'reference_source':inst.meta['reference_source'],
           'fichier':f'data/preparees/{nom}.json'})
        tailles=[10,20,30,40,60,80] if nom!='p12' else [10,20,30,40,60]
        for taille in tailles:
            sub=sous_instance(inst,taille)
            sub.to_json(str(sortie/f'{sub.name}.json'))
            catalogue.append({'instance':sub.name,'famille':'sous_instance','parent':nom,
                'clients':sub.n,'depots':sub.m,'reference':None,'reference_source':None,
                'fichier':f'data/preparees/{sub.name}.json'})
    assert len(catalogue)==20
    for nom,rows in [('inventaire_instances.csv',inventaire),('catalogue_20_instances.csv',catalogue)]:
        with (ROOT/nom).open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    print(f'{len(inventaire)} fichiers lus ; {len(catalogue)} instances preparees.')
    return catalogue

if __name__=='__main__':preparer()
