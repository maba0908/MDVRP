
"""Comparaison Hill Climbing / Recherche tabou sur 20 instances."""

import csv
from pathlib import Path

from donnees_mdvrp import MDVRPInstance
from integration import convertir_instance
from preparer_donnees import preparer
from solveur_mdvrp import executer

ROOT = Path(__file__).resolve().parent


def comparer_20_instances():

    # Préparation des données si nécessaire
    if not (ROOT / "catalogue_20_instances.csv").exists():
        preparer()

    # Récupération des 20 instances originales
    with (ROOT / "catalogue_20_instances.csv").open(
        encoding="utf-8"
    ) as f:
        catalogue = list(csv.DictReader(f))

    fichiers = [
        ROOT / ligne["fichier"]
        for ligne in catalogue
    ]

    if len(fichiers) != 20:
        raise ValueError(
            f"20 instances attendues, {len(fichiers)} trouvées."
        )

    print("Familles présentes :")

    dossier_resultats = ROOT / "resultats" / "comparaison_20"
    dossier_resultats.mkdir(parents=True, exist_ok=True)

    lignes = []

    # Exécution des deux algorithmes
    for fichier in fichiers:
        nom = fichier.stem

        print(f"\n{'=' * 45}")
        print(f"INSTANCE : {nom}")
        print(f"{'=' * 45}")

        source = MDVRPInstance.from_json(str(fichier))
        cible = convertir_instance(source)

        resultat = executer(
            cible,
            dossier=dossier_resultats / nom,
            seed=42,
            iterations=300,
            tenure=7,
            stagnation=100,
            secondes=10,
            ordre="random",
            local=True,
            graphiques=False,
            afficher=False
        )

        # Lecture du résumé généré par executer()
        resume_path = dossier_resultats / nom / "resume.csv"

        with resume_path.open(encoding="utf-8") as f:
            resume = next(csv.DictReader(f))

        cout_hc = float(resume["cout_local"])
        cout_tabou = float(resume["cout_tabou"])

        temps_hc = float(resume["temps_local_s"])
        temps_tabou = float(resume["temps_tabou_s"])

        # Gain de la recherche tabou par rapport au HC
        gain = (
            100 * (cout_hc - cout_tabou) / cout_hc
            if cout_hc > 0 else 0
        )

        lignes.append({
            "Instance": nom,
            "Clients": resume["clients"],
            "Coût initial": resume["cout_initial"],
            "Coût HC": cout_hc,
            "Temps HC (s)": temps_hc,
            "Arrêt HC": resume["arret_local"],
            "Coût tabou": cout_tabou,
            "Temps tabou (s)": temps_tabou,
            "Arrêt tabou": resume["arret"],
            "Gain tabou (%)": gain
        })

        print(
            f"HC : {cout_hc:.2f} ({temps_hc:.4f} s) | "
            f"Tabou : {cout_tabou:.2f} ({temps_tabou:.4f} s) | "
            f"Gain : {gain:.2f} %"
        )

    # Création du tableau CSV
    fichier_csv = dossier_resultats / "comparaison_20.csv"

    with fichier_csv.open(
        "w", newline="", encoding="utf-8-sig"
    ) as f:
        writer = csv.DictWriter(
            f,
            fieldnames=lignes[0].keys(),
            delimiter=";"
        )
        writer.writeheader()
        writer.writerows(lignes)

    # Affichage du tableau dans le terminal
    print("\n\n========== TABLEAU COMPARATIF ==========\n")

    entetes = list(lignes[0].keys())
    largeurs = {
        cle: max(
            len(cle),
            max(len(str(ligne[cle])) for ligne in lignes)
        )
        for cle in entetes
    }

    print(" | ".join(c.ljust(largeurs[c]) for c in entetes))
    print("-+-".join("-" * largeurs[c] for c in entetes))

    for ligne in lignes:
        print(" | ".join(
            str(ligne[c]).ljust(largeurs[c])
            for c in entetes
        ))

    print("\nFichier enregistré :", fichier_csv)

    # Quelques statistiques globales
    nb_tabou = sum(
        1 for ligne in lignes
        if float(ligne["Gain tabou (%)"]) > 0
    )

    nb_hc = sum(
        1 for ligne in lignes
        if float(ligne["Gain tabou (%)"]) < 0
    )

    gains = [float(ligne["Gain tabou (%)"]) for ligne in lignes]

    print("\n========== BILAN GLOBAL ==========")
    print(f"Tabou meilleur : {nb_tabou}/20 instances")
    print(f"HC meilleur : {nb_hc}/20 instances")
    print(f"Égalité : {20 - nb_tabou - nb_hc}/20 instances")
    print(f"Gain moyen du tabou : {sum(gains) / len(gains):.2f} %")


if __name__ == "__main__":
    comparer_20_instances()
