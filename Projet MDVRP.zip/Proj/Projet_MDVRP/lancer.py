"""Démo complète : lecteur Lionel -> tabou -> vérification Lionel -> exports."""
from pathlib import Path
import argparse,csv,json,time
import matplotlib.pyplot as plt
from donnees_mdvrp import MDVRPInstance,plot_solution,save_solution
from integration import convertir_instance,exporter_routes,verifier_commun
from solveur_mdvrp import construire_initiale,recherche_locale,recherche_tabou
from preparer_donnees import preparer

ROOT=Path(__file__).resolve().parent

def resoudre(nom='p12',secondes=10,seed=42,sortie=None,fenetre=True):
    if not (ROOT/'catalogue_20_instances.csv').exists():preparer()
    path=ROOT/'data'/'preparees'/f'{nom}.json'
    source=MDVRPInstance.from_json(str(path))
    cible=convertir_instance(source)
    debut=time.perf_counter()
    initiale=construire_initiale(cible,seed=seed,ordre='random')
    temps_initial=time.perf_counter()-debut
    debut = time.perf_counter()
    locale = recherche_locale(cible, initiale)
    temps_local = time.perf_counter() - debut

    verifier_commun(source,cible,initiale)
    resultat=recherche_tabou(cible,initiale,iterations_max=1000,
                   duree_tabou=7,stagnation_max=250,temps_max=secondes)
    rep=verifier_commun(source,cible,resultat['solution'])
    out=Path(sortie) if sortie else ROOT/'resultats'/nom
    out.mkdir(parents=True,exist_ok=True)
    save_solution(str(out/'solution_tabou.json'),source,exporter_routes(source,resultat['solution']),
                  method='recherche tabou',extra={'seed':seed,'temps_s':resultat['temps_s'],
                   'temps_initial_s':temps_initial,'iterations':resultat['iterations']})
    with (out/'historique.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=resultat['historique'][0]);w.writeheader();w.writerows(resultat['historique'])
    
    fig,axes=plt.subplots(1,3,figsize=(18,6))
    plot_solution(
        source, exporter_routes(source, initiale),
        ax=axes[0],
        title=f'Initiale : {initiale.cost(cible):.2f}'
    )

    plot_solution(
        source, exporter_routes(source, locale),
        ax=axes[1],
        title=f'Hill Climbing : {locale.cost(cible):.2f}'
    )

    plot_solution(
        source, exporter_routes(source, resultat['solution']),
        ax=axes[2],
        title=f'Tabou : {rep.cost:.2f}'
    )
    fig.tight_layout();fig.savefig(out/'tournees.png',dpi=150,bbox_inches='tight')
    fig2,ax=plt.subplots(figsize=(8,4));h=resultat['historique']
    ax.plot([x['temps_s'] for x in h],[x['cout_courant'] for x in h],alpha=.5,label='Coût courant')
    ax.plot([x['temps_s'] for x in h],[x['meilleur_cout'] for x in h],label='Meilleur coût')
    ax.set(xlabel='Temps (s)',ylabel='Distance',title=nom);ax.legend();fig2.tight_layout()
    fig2.savefig(out/'convergence.png',dpi=150)
    if fenetre:plt.show()
    else:plt.close(fig);plt.close(fig2)
    print(source);print(rep)
    print(f'Départ : {initiale.cost(cible):.2f}')
    print(f'Hill Climbing : {locale.cost(cible):.2f} | Temps : {temps_local:.4f} s')
    print(f'Recherche tabou : {rep.cost:.2f} | Temps : {resultat["temps_s"]:.4f} s')
    if source.bks:print(f'Ecart à la reference du guide : {100*(rep.cost-source.bks)/source.bks:.2f} %')
    print('Fichiers :',out)
    return resultat

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--instance',default='p12')
    p.add_argument('--secondes',type=float,default=10);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--sans-fenetre',action='store_true');a=p.parse_args()
    resoudre(a.instance,a.secondes,a.seed,fenetre=not a.sans_fenetre)

    
